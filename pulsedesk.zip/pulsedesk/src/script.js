/* ========= PulseDesk: PIN ONLY ========= */
const $ = (q) => document.querySelector(q);
const $$ = (q) => document.querySelectorAll(q);

/* ---------- Storage Keys ---------- */
const PIN_KEY = "pd_pin_v1";
const PROFILE_KEY = "pd_profile_v1";
const DATA_KEY = "pd_data_v1";
const THEME_KEY = "pd_theme_v1";
const PRO_KEY = "pd_pro_v1";
const LOCALE_KEY = "pd_locale_v1";
const CURR_KEY = "pd_currency_v1";

/* ---------- Defaults ---------- */
const DEFAULT_PIN = "1234";

const THEME_DEFAULT = {
  mode: "dark",
  primary: "#7c5cff",
  accent: "#00e5ff",
  bgGlow: "#1b1c4d",
  radius: 16,
  density: 1,
  fontScale: 1,
  modules: {
    money: true,
    workflow: true,
    team: true,
    meetings: true,
    insights: true
  }
};
const PROFILE_DEFAULT = {
  name: "Guest",
  role: "Workspace",
  email: "",
  avatar: "G",
  timezone: "America/Jamaica",
  pin: DEFAULT_PIN
};
const PRO_DEFAULT = { isPro: false, since: null, proMembers: [] };

const DEMO = {
  money: {
    incomes: [
      {
        id: id(),
        title: "Salary",
        amount: 190000,
        date: todayISO(),
        recurring: "monthly"
      },
      {
        id: id(),
        title: "Extra Tutoring",
        amount: 15000,
        date: todayISO(),
        recurring: "weekly"
      }
    ],
    bills: [
      {
        id: id(),
        title: "Light Bill",
        amount: 12000,
        due: addDaysISO(5),
        paid: false,
        kind: "bill"
      },
      {
        id: id(),
        title: "Internet",
        amount: 6500,
        due: addDaysISO(2),
        paid: true,
        kind: "bill"
      },
      {
        id: id(),
        title: "Student Loan",
        amount: 24000,
        due: addDaysISO(12),
        paid: false,
        kind: "loan"
      }
    ]
  },
  tasks: [
    {
      id: id(),
      title: "Grade 6 Language Plan",
      priority: "high",
      col: "todo",
      due: addDaysISO(3),
      tag: "school"
    },
    {
      id: id(),
      title: "Update Portfolio",
      priority: "med",
      col: "doing",
      due: addDaysISO(1),
      tag: "mico"
    },
    {
      id: id(),
      title: "Pay Internet",
      priority: "low",
      col: "done",
      due: addDaysISO(0),
      tag: "bills"
    }
  ],
  members: [
    { id: id(), name: "Kevor", role: "Lead", color: "K" },
    { id: id(), name: "Shanice", role: "Admin", color: "S" },
    { id: id(), name: "Andre", role: "Tech Support", color: "A" }
  ],
  assignments: [
    {
      id: id(),
      task: "Prepare Quiz",
      memberId: null,
      status: "assigned",
      due: addDaysISO(2)
    },
    {
      id: id(),
      task: "Upload Grades",
      memberId: null,
      status: "in review",
      due: addDaysISO(6)
    }
  ],
  meetings: [
    {
      id: id(),
      title: "Team Check-in",
      date: addDaysISO(1),
      time: "10:00",
      place: "Staff Room",
      with: ["Shanice", "Andre"]
    },
    {
      id: id(),
      title: "Parent Call",
      date: addDaysISO(3),
      time: "15:30",
      place: "Zoom",
      with: ["Parent"]
    }
  ],
  activity: []
};

/* ---------- State ---------- */
let state = load(DATA_KEY) || structuredClone(DEMO);
let profile = load(PROFILE_KEY) || structuredClone(PROFILE_DEFAULT);
let theme = load(THEME_KEY) || structuredClone(THEME_DEFAULT);
let pro = load(PRO_KEY) || structuredClone(PRO_DEFAULT);
let locale = localStorage.getItem(LOCALE_KEY) || navigator.language || "en-US";
let currency = localStorage.getItem(CURR_KEY) || "USD";
let priorityFilter = "all";

/* Ensure pin exists */
if (!localStorage.getItem(PIN_KEY)) {
  localStorage.setItem(PIN_KEY, DEFAULT_PIN);
}
profile.pin = localStorage.getItem(PIN_KEY);

/* ---------- Panes ---------- */
const panes = {
  overview: $("#overviewPane"),
  money: $("#moneyPane"),
  workflow: $("#workflowPane"),
  team: $("#teamPane"),
  meetings: $("#meetingsPane"),
  insights: $("#insightsPane"),
  profile: $("#profilePane"),
  subscription: $("#subscriptionPane"),
  studio: $("#studioPane")
};

/* ===================== PIN GATE ===================== */
initPinGate();
lockApp();

function initPinGate() {
  $("#pinUnlockBtn").onclick = tryUnlock;
  $("#pinInput").addEventListener("keydown", (e) => {
    if (e.key === "Enter") tryUnlock();
  });
}

function lockApp() {
  $("#pinGate").style.display = "grid";
  $("#planPill").textContent = "LOCKED";
  $("#pinInput").value = "";
  $("#pinInput").focus();
}

function tryUnlock() {
  const entered = $("#pinInput").value.trim();
  const correct = localStorage.getItem(PIN_KEY);

  if (entered === correct) {
    $("#pinMsg").textContent = "";
    $("#pinGate").style.display = "none";
    $("#planPill").textContent = pro.isPro ? "PRO" : "FREE";
    renderAll();
    showWelcome(profile.name || "User");
  } else {
    $("#pinMsg").textContent = "Wrong PIN. Try again.";
    $("#pinInput").value = "";
    $("#pinInput").focus();
  }
}

/* ========================= INIT APP ========================= */
initTabs();
initLocaleCurrencySelectors();
initStudio();
bindButtons();

/* ========================= RENDER ========================= */
function renderAll() {
  applyTheme();
  applyModuleVisibility();
  renderProfileCard();
  renderGreeting();

  // Make panes content fresh each time
  renderOverviewPane();
  renderMoneyPane();
  renderWorkflowPane();
  renderTeamPane();
  renderMeetingsPane();
  renderInsightsPane();
  renderProfilePane();
  renderSubscriptionPane();
}

/* ---------- Tabs ---------- */
function initTabs() {
  $$(".tab").forEach((btn) => {
    btn.onclick = () => {
      $$(".tab").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      const tab = btn.dataset.tab;
      Object.values(panes).forEach((p) => p.classList.remove("show"));
      panes[tab].classList.add("show");
    };
  });
}

/* ---------- Core UI ---------- */
function renderProfileCard() {
  $("#profileName").textContent = profile.name || "Guest";
  $("#profileRole").textContent = profile.role || "Workspace";
  $("#profileAvatar").textContent = (
    profile.avatar || initials(profile.name)
  ).toUpperCase();
}
function renderGreeting() {
  $("#greetTitle").textContent = `Welcome, ${profile.name || "Guest"} 👋`;
  $("#greetSubtitle").textContent = "Your money + work in order.";
  $("#todayChip").textContent = new Date().toLocaleDateString(locale);
}

/* ===================== PANES CONTENT ===================== */
function renderOverviewPane() {
  panes.overview.innerHTML = `
    <div class="grid-2">
      <div class="card hero module" data-module="money">
        <div class="hero-row">
          <div>
            <h3>Monthly Pulse</h3>
            <p class="muted">Income, bills, loans, savings.</p>
          </div>
          <button class="btn ghost mini" id="addMoneyBtn">+ Add Money</button>
        </div>
        <div class="hero-stats" id="heroStats"></div>
        <div class="meter"><div class="meter-bar" id="savingsBar"></div></div>
        <div class="meter-meta">
          <span>Saving Progress</span><span id="savingsText"></span>
        </div>
      </div>

      <div class="card module" data-module="workflow">
        <div class="title-row">
          <h3>Today’s Focus</h3>
          <button class="btn ghost mini" id="addTaskBtn">+ Add Task</button>
        </div>
        <div class="list" id="todayTasks"></div>
      </div>
    </div>
  `;
  $("#addMoneyBtn").onclick = () => openMoneyModal("income");
  $("#addTaskBtn").onclick = () => openTaskModal();
  renderHero();
  renderTodayTasks();
}

function renderMoneyPane() {
  panes.money.innerHTML = `
    <div class="grid-2">
      <div class="card">
        <div class="title-row">
          <h3>Salary & Income</h3>
          <button class="btn ghost mini" id="addIncomeBtn">+ Add Income</button>
        </div>
        <div class="list" id="incomeList"></div>
      </div>

      <div class="card">
        <div class="title-row">
          <h3>Bills & Loans</h3>
          <button class="btn ghost mini" id="addBillBtn">+ Add Bill/Loan</button>
        </div>
        <div class="list" id="billList"></div>
      </div>
    </div>
    <div class="card">
      <div class="title-row">
        <h3>Money Breakdown</h3>
        <div class="tiny muted">Auto totals</div>
      </div>
      <div class="breakdown" id="moneyBreakdown"></div>
    </div>
  `;
  $("#addIncomeBtn").onclick = () => openMoneyModal("income");
  $("#addBillBtn").onclick = () => openMoneyModal("bill");
  renderMoney();
}

function renderWorkflowPane() {
  panes.workflow.innerHTML = `
    <div class="board-head">
      <div>
        <h3>Workflow Board</h3>
        <p class="muted">Drag tasks to update status.</p>
      </div>
      <div class="board-actions">
        <button class="btn" id="newBoardTask">+ New Task</button>
        <select id="priorityFilter">
          <option value="all">All priority</option>
          <option value="high">High</option>
          <option value="med">Medium</option>
          <option value="low">Low</option>
        </select>
      </div>
    </div>

    <div class="kanban">
      <div class="col">
        <div class="col-head"><h4>To-Do</h4><span class="pill" id="todoCount">0</span></div>
        <div class="col-body drop" id="todoCol"></div>
      </div>
      <div class="col">
        <div class="col-head"><h4>Doing</h4><span class="pill" id="doingCount">0</span></div>
        <div class="col-body drop" id="doingCol"></div>
      </div>
      <div class="col">
        <div class="col-head"><h4>Done</h4><span class="pill" id="doneCount">0</span></div>
        <div class="col-body drop" id="doneCol"></div>
      </div>
    </div>
  `;
  $("#newBoardTask").onclick = () => openTaskModal();
  $("#priorityFilter").value = priorityFilter;
  $("#priorityFilter").onchange = (e) => {
    priorityFilter = e.target.value;
    renderKanban();
  };
  renderKanban();
}

function renderTeamPane() {
  panes.team.innerHTML = `
    <div class="grid-2">
      <div class="card">
        <div class="title-row">
          <h3>Team Members</h3>
          <button class="btn ghost mini" id="addMemberBtn">+ Add Member</button>
        </div>
        <div class="members" id="memberGrid"></div>
      </div>

      <div class="card">
        <div class="title-row">
          <h3>Assignments</h3>
          <button class="btn ghost mini" id="addAssignBtn">+ Assign Task</button>
        </div>
        <div class="list" id="assignmentList"></div>
      </div>
    </div>
  `;
  $("#addMemberBtn").onclick = openMemberModal;
  $("#addAssignBtn").onclick = openAssignModal;
  renderTeam();
}

function renderMeetingsPane() {
  panes.meetings.innerHTML = `
    <div class="card">
      <div class="title-row">
        <h3>Meetings Planner</h3>
        <button class="btn" id="createMeetBtn">+ New Meeting</button>
      </div>
      <div class="meetings" id="meetingsGrid"></div>
    </div>
  `;
  $("#createMeetBtn").onclick = openMeetingModal;
  renderMeetingsPage();
}

function renderInsightsPane() {
  panes.insights.innerHTML = `
    <div class="grid-3">
      <div class="card kpi">
        <h4>Work Completion</h4>
        <div class="big" id="kpiWork">0%</div>
        <p class="muted">Done vs total tasks</p>
      </div>
      <div class="card kpi">
        <h4>Money Health</h4>
        <div class="big" id="kpiMoney">0%</div>
        <p class="muted">Savings rate</p>
      </div>
      <div class="card kpi">
        <h4>On-time Bills</h4>
        <div class="big" id="kpiBills">0%</div>
        <p class="muted">Paid vs due</p>
      </div>
    </div>
    <div class="card">
      <div class="title-row">
        <h3>Activity Timeline</h3>
        <div class="tiny muted">Last actions</div>
      </div>
      <div class="list" id="activityList"></div>
    </div>
  `;
  renderInsights();
}

function renderProfilePane() {
  panes.profile.innerHTML = `
    <div class="card">
      <div class="title-row">
        <h3>👤 Profile</h3>
        <div class="tiny muted">Personalize + change PIN</div>
      </div>

      <div class="studio-grid">
        <div class="field"><label>Full Name</label><input id="p_name" value="${
          profile.name || ""
        }"></div>
        <div class="field"><label>Role / Title</label><input id="p_role" value="${
          profile.role || ""
        }"></div>
        <div class="field"><label>Avatar Initials</label><input id="p_avatar" maxlength="3" value="${
          profile.avatar || ""
        }"></div>

        <div class="field">
          <label>Change PIN</label>
          <input id="p_pin" type="password" maxlength="6" placeholder="New PIN">
        </div>
      </div>

      <div class="studio-actions">
        <button class="btn ghost" id="resetProfile">Reset</button>
        <button class="btn primary" id="saveProfile">Save Profile</button>
        <button class="btn" id="lockNowBtn">Lock Now</button>
      </div>
    </div>
  `;

  $("#saveProfile").onclick = saveProfileFromUI;
  $("#resetProfile").onclick = resetProfile;
  $("#lockNowBtn").onclick = lockApp;
}

function renderSubscriptionPane() {
  panes.subscription.innerHTML = `
    <div class="card">
      <h3>💳 PulseDesk Pro</h3>
      <p class="muted">Demo only. $3.99 USD/month.</p>
      <button class="btn primary" onclick="upgradeToPro()">Upgrade to Pro</button>
      <button class="btn ghost" onclick="cancelPro()">Cancel Pro</button>
    </div>
  `;
}

/* ===================== Core Render Helpers ===================== */
function renderHero() {
  const income = sum(state.money.incomes.map((i) => i.amount));
  const bills = sum(state.money.bills.map((b) => b.amount));
  const savings = Math.max(0, income - bills);
  const rate = income ? Math.round((savings / income) * 100) : 0;

  $("#heroStats").innerHTML = `
    <div class="hstat"><div class="label">Income</div><div class="value">${fmt(
      income
    )}</div></div>
    <div class="hstat"><div class="label">Bills + Loans</div><div class="value">${fmt(
      bills
    )}</div></div>
    <div class="hstat"><div class="label">Savings</div><div class="value">${fmt(
      savings
    )}</div></div>
  `;
  $("#savingsBar").style.width = `${rate}%`;
  $("#savingsText").textContent = `${rate}%`;
}

function renderTodayTasks() {
  const list = $("#todayTasks");
  const upcoming = state.tasks
    .filter((t) => t.col !== "done")
    .sort((a, b) => new Date(a.due) - new Date(b.due))
    .slice(0, 5);

  list.innerHTML = upcoming.length
    ? upcoming
        .map(
          (t) => `
    <div class="item">
      <div class="left">
        <div class="title">${t.title}</div>
        <div class="sub">Due ${prettyDate(t.due)} • #${t.tag}</div>
      </div>
      <div class="right">
        <span class="badge ${prioClass(t.priority)}">${t.priority}</span>
      </div>
    </div>`
        )
        .join("")
    : empty("No tasks yet.");
}

function renderMoney() {
  $("#incomeList").innerHTML =
    state.money.incomes
      .map(
        (i) => `
    <div class="item">
      <div class="left">
        <div class="title">${i.title}</div>
        <div class="sub">${prettyDate(i.date)} • ${i.recurring}</div>
      </div>
      <div class="right">
        <span class="badge green">${fmt(i.amount)}</span>
        <button class="btn ghost mini" onclick="delIncome('${
          i.id
        }')">Del</button>
      </div>
    </div>`
      )
      .join("") || empty("Add income.");

  $("#billList").innerHTML =
    state.money.bills
      .map(
        (b) => `
    <div class="item">
      <div class="left">
        <div class="title">${b.title}</div>
        <div class="sub">Due ${prettyDate(b.due)} • ${b.kind}</div>
      </div>
      <div class="right">
        <button class="btn ghost mini" onclick="togglePaid('${b.id}')">${
          b.paid ? "Paid ✅" : "Mark Paid"
        }</button>
        <span class="badge ${b.kind === "loan" ? "orange" : "red"}">${fmt(
          b.amount
        )}</span>
        <button class="btn ghost mini" onclick="delBill('${b.id}')">Del</button>
      </div>
    </div>`
      )
      .join("") || empty("Add bills/loans.");

  const income = sum(state.money.incomes.map((i) => i.amount));
  const bills = sum(state.money.bills.map((b) => b.amount));
  const savings = Math.max(0, income - bills);

  $("#moneyBreakdown").innerHTML = `
    <div class="hstat"><div class="label">Total Income</div><div class="value">${fmt(
      income
    )}</div></div>
    <div class="hstat"><div class="label">Total Bills/Loans</div><div class="value">${fmt(
      bills
    )}</div></div>
    <div class="hstat"><div class="label">Projected Savings</div><div class="value">${fmt(
      savings
    )}</div></div>`;
}

function renderKanban() {
  const tasks = state.tasks.filter(
    (t) => priorityFilter === "all" || t.priority === priorityFilter
  );
  $("#todoCol").innerHTML = tasks
    .filter((t) => t.col === "todo")
    .map(taskCard)
    .join("");
  $("#doingCol").innerHTML = tasks
    .filter((t) => t.col === "doing")
    .map(taskCard)
    .join("");
  $("#doneCol").innerHTML = tasks
    .filter((t) => t.col === "done")
    .map(taskCard)
    .join("");

  $("#todoCount").textContent = state.tasks.filter(
    (t) => t.col === "todo"
  ).length;
  $("#doingCount").textContent = state.tasks.filter(
    (t) => t.col === "doing"
  ).length;
  $("#doneCount").textContent = state.tasks.filter(
    (t) => t.col === "done"
  ).length;

  bindDrag();
}

function taskCard(t) {
  return `
    <div class="task drag" draggable="true" data-id="${t.id}">
      <div class="t-title">${t.title}</div>
      <div class="t-meta">
        <span class="badge ${prioClass(t.priority)}">${t.priority}</span>
        <span>Due ${prettyDate(t.due)}</span>
        <span>#${t.tag}</span>
      </div>
      <div class="t-foot">
        <button class="btn ghost mini" onclick="editTask('${
          t.id
        }')">Edit</button>
        <button class="btn ghost mini" onclick="delTask('${t.id}')">Del</button>
      </div>
    </div>`;
}

function renderTeam() {
  $("#memberGrid").innerHTML =
    state.members
      .map(
        (m) => `
    <div class="member">
      <div class="row">
        <div class="avatar">${m.color}</div>
        <div>
          <div class="m-name">${m.name}</div>
          <div class="m-role muted tiny">${m.role}</div>
        </div>
      </div>
      <button class="btn ghost mini" onclick="delMember('${m.id}')">Remove</button>
    </div>`
      )
      .join("") || empty("Add members.");

  $("#assignmentList").innerHTML =
    state.assignments
      .map((a) => {
        const mem = state.members.find((m) => m.id === a.memberId);
        return `
      <div class="item">
        <div class="left">
          <div class="title">${a.task}</div>
          <div class="sub">Due ${prettyDate(a.due)}</div>
        </div>
        <div class="right">
          <span class="badge purple">${mem ? mem.name : "Unassigned"}</span>
          <span class="badge ${statusClass(a.status)}">${a.status}</span>
          <button class="btn ghost mini" onclick="delAssign('${
            a.id
          }')">Del</button>
        </div>
      </div>`;
      })
      .join("") || empty("Assign tasks.");
}

function renderMeetingsPage() {
  $("#meetingsGrid").innerHTML =
    state.meetings
      .map(
        (m) => `
    <div class="meet-card">
      <div class="meet-title">${m.title}</div>
      <div class="muted tiny">📅 ${prettyDate(m.date)} • ⏰ ${m.time}</div>
      <div class="muted tiny">📍 ${m.place}</div>
      <div class="muted tiny">With: ${m.with.join(", ")}</div>
      <button class="btn ghost mini" onclick="delMeet('${
        m.id
      }')">Delete</button>
    </div>`
      )
      .join("") || empty("Create meetings.");
}

function renderInsights() {
  const totalTasks = state.tasks.length || 1;
  const doneTasks = state.tasks.filter((t) => t.col === "done").length;
  $("#kpiWork").textContent = `${Math.round((doneTasks / totalTasks) * 100)}%`;

  const income = sum(state.money.incomes.map((i) => i.amount));
  const bills = sum(state.money.bills.map((b) => b.amount));
  const savings = Math.max(0, income - bills);
  $("#kpiMoney").textContent = `${
    income ? Math.round((savings / income) * 100) : 0
  }%`;

  const totalBills = state.money.bills.length || 1;
  const paidBills = state.money.bills.filter((b) => b.paid).length;
  $("#kpiBills").textContent = `${Math.round((paidBills / totalBills) * 100)}%`;

  $("#activityList").innerHTML =
    state.activity
      .slice(0, 12)
      .map(
        (a) => `
    <div class="item">
      <div class="left">
        <div class="title">${a.text}</div>
        <div class="sub">${new Date(a.time).toLocaleString(locale)}</div>
      </div>
      <div class="right"><span class="badge blue">${a.type}</span></div>
    </div>`
      )
      .join("") || empty("No activity yet.");
}

/* ===================== MODALS (same as earlier) ===================== */
function bindButtons() {
  $("#quickAdd").onclick = openQuickAdd;
  $("#resetAppBtn").onclick = resetDemo;
  $("#exportBtnSide").onclick = exportJSON;
  $("#exportBtn").onclick = exportJSON;

  $("#modalClose").onclick = closeModal;
  $("#modalBg").onclick = closeModal;
  $("#modalCancel").onclick = closeModal;
}
function openQuickAdd() {
  openModal(
    "Quick Add",
    `
    <button class="btn w-full" onclick="openMoneyModal('income')">Add Income</button>
    <button class="btn w-full" onclick="openMoneyModal('bill')">Add Bill/Loan</button>
    <button class="btn w-full" onclick="openTaskModal()">Add Task</button>
    <button class="btn w-full" onclick="openMeetingModal()">Add Meeting</button>
    <button class="btn w-full" onclick="openAssignModal()">Assign Task</button>
  `,
    null
  );
}
function openMoneyModal(kind) {
  const isIncome = kind === "income";
  openModal(
    isIncome ? "Add Income" : "Add Bill/Loan",
    `
    <div class="field"><label>Title</label><input id="m_title"/></div>
    <div class="field"><label>Amount</label><input id="m_amount" type="number"/></div>
    <div class="field"><label>${isIncome ? "Date Received" : "Due Date"}</label>
      <input id="m_date" type="date" value="${todayISO()}"/>
    </div>
    ${
      isIncome
        ? `
      <div class="field"><label>Recurring</label>
        <select id="m_recurring">
          <option value="one-time">One-time</option>
          <option value="weekly">Weekly</option>
          <option value="monthly" selected>Monthly</option>
        </select>
      </div>`
        : `
      <div class="field"><label>Type</label>
        <select id="m_kind"><option value="bill">Bill</option><option value="loan">Loan</option></select>
      </div>`
    }
  `,
    () => {
      const title = $("#m_title").value.trim();
      const amount = +$("#m_amount").value;
      const date = $("#m_date").value;
      if (!title || !amount) return;

      if (isIncome) {
        state.money.incomes.unshift({
          id: id(),
          title,
          amount,
          date,
          recurring: $("#m_recurring").value
        });
        log("money", "Added income");
      } else {
        state.money.bills.unshift({
          id: id(),
          title,
          amount,
          due: date,
          paid: false,
          kind: $("#m_kind").value
        });
        log("money", "Added bill/loan");
      }
      persistAll();
      renderAll();
      closeModal();
    }
  );
}
function openTaskModal(existingId = null) {
  const t = existingId ? state.tasks.find((x) => x.id === existingId) : null;
  openModal(
    t ? "Edit Task" : "Add Task",
    `
    <div class="field"><label>Task Title</label><input id="t_title" value="${
      t?.title || ""
    }"/></div>
    <div class="field"><label>Priority</label>
      <select id="t_prio">
        <option ${t?.priority === "high" ? "selected" : ""}>high</option>
        <option ${t?.priority === "med" ? "selected" : ""}>med</option>
        <option ${t?.priority === "low" ? "selected" : ""}>low</option>
      </select>
    </div>
    <div class="field"><label>Due date</label>
      <input id="t_due" type="date" value="${t?.due || todayISO()}"/>
    </div>
    <div class="field"><label>Tag</label><input id="t_tag" value="${
      t?.tag || ""
    }"/></div>
    ${
      t
        ? `
      <div class="field"><label>Status</label>
        <select id="t_col">
          <option value="todo" ${
            t.col === "todo" ? "selected" : ""
          }>todo</option>
          <option value="doing" ${
            t.col === "doing" ? "selected" : ""
          }>doing</option>
          <option value="done" ${
            t.col === "done" ? "selected" : ""
          }>done</option>
        </select>
      </div>`
        : ""
    }
  `,
    () => {
      const title = $("#t_title").value.trim();
      if (!title) return;

      const priority = $("#t_prio").value;
      const due = $("#t_due").value;
      const tag = $("#t_tag").value.trim() || "general";

      if (t) {
        t.title = title;
        t.priority = priority;
        t.due = due;
        t.tag = tag;
        if ($("#t_col")) t.col = $("#t_col").value;
        log("work", "Updated task");
      } else {
        state.tasks.unshift({
          id: id(),
          title,
          priority,
          col: "todo",
          due,
          tag
        });
        log("work", "Added task");
      }
      persistAll();
      renderAll();
      closeModal();
    }
  );
}
function openMemberModal() {
  openModal(
    "Add Team Member",
    `
    <div class="field"><label>Name</label><input id="mem_name"/></div>
    <div class="field"><label>Role</label><input id="mem_role"/></div>
  `,
    () => {
      const name = $("#mem_name").value.trim();
      const role = $("#mem_role").value.trim() || "Member";
      if (!name) return;
      state.members.push({
        id: id(),
        name,
        role,
        color: name[0].toUpperCase()
      });
      log("team", "Added member");
      persistAll();
      renderAll();
      closeModal();
    }
  );
}
function openAssignModal() {
  openModal(
    "Assign Task",
    `
    <div class="field"><label>Task</label><input id="a_task"/></div>
    <div class="field"><label>Member</label>
      <select id="a_member">
        <option value="">Unassigned</option>
        ${state.members
          .map((m) => `<option value="${m.id}">${m.name}</option>`)
          .join("")}
      </select>
    </div>
    <div class="field"><label>Status</label>
      <select id="a_status"><option>assigned</option><option>in review</option><option>completed</option></select>
    </div>
    <div class="field"><label>Due date</label><input id="a_due" type="date" value="${todayISO()}"/></div>
  `,
    () => {
      const task = $("#a_task").value.trim();
      if (!task) return;
      state.assignments.unshift({
        id: id(),
        task,
        memberId: $("#a_member").value || null,
        status: $("#a_status").value,
        due: $("#a_due").value
      });
      log("team", "Assigned task");
      persistAll();
      renderAll();
      closeModal();
    }
  );
}
function openMeetingModal() {
  openModal(
    "New Meeting",
    `
    <div class="field"><label>Title</label><input id="meet_title"/></div>
    <div class="field"><label>Date</label><input id="meet_date" type="date" value="${todayISO()}"/></div>
    <div class="field"><label>Time</label><input id="meet_time" type="time" value="10:00"/></div>
    <div class="field"><label>Place</label><input id="meet_place"/></div>
    <div class="field"><label>With (comma separated)</label><input id="meet_with"/></div>
  `,
    () => {
      const title = $("#meet_title").value.trim();
      if (!title) return;
      state.meetings.unshift({
        id: id(),
        title,
        date: $("#meet_date").value,
        time: $("#meet_time").value,
        place: $("#meet_place").value.trim() || "TBD",
        with: $("#meet_with")
          .value.split(",")
          .map((x) => x.trim())
          .filter(Boolean)
      });
      log("meetings", "Added meeting");
      persistAll();
      renderAll();
      closeModal();
    }
  );
}
function openModal(title, bodyHTML, onSave) {
  $("#modalTitle").textContent = title;
  $("#modalBody").innerHTML = bodyHTML;
  $("#modal").classList.remove("hidden");
  $("#modalSave").onclick = onSave || closeModal;
}
function closeModal() {
  $("#modal").classList.add("hidden");
  $("#modalBody").innerHTML = "";
}

/* ===================== DRAG/DROP ===================== */
function bindDrag() {
  $$(".drag").forEach((card) => {
    card.ondragstart = (e) =>
      e.dataTransfer.setData("text/plain", card.dataset.id);
  });
  $$(".drop").forEach((col) => {
    col.ondragover = (e) => e.preventDefault();
    col.ondrop = (e) => {
      e.preventDefault();
      const idVal = e.dataTransfer.getData("text/plain");
      const task = state.tasks.find((t) => t.id === idVal);
      if (!task) return;
      task.col = col.id.replace("Col", "");
      log("work", `Moved task to ${task.col}`);
      persistAll();
      renderAll();
    };
  });
}

/* ===================== PROFILE / PIN SAVE ===================== */
function saveProfileFromUI() {
  profile.name = $("#p_name").value.trim() || profile.name;
  profile.role = $("#p_role").value.trim() || profile.role;
  profile.avatar = ($("#p_avatar").value.trim() || initials(profile.name))
    .slice(0, 3)
    .toUpperCase();

  const newPin = $("#p_pin").value.trim();
  if (newPin) {
    localStorage.setItem(PIN_KEY, newPin);
    profile.pin = newPin;
    log("security", "Updated PIN");
    alert("PIN updated!");
  }
  persistAll();
  renderAll();
}
function resetProfile() {
  profile = structuredClone(PROFILE_DEFAULT);
  localStorage.setItem(PIN_KEY, DEFAULT_PIN);
  persistAll();
  renderAll();
}

/* ===================== PRO (DEMO) ===================== */
window.upgradeToPro = () => {
  pro.isPro = true;
  pro.since = Date.now();
  profile.role = "Pro User";
  log("subscription", "Upgraded to Pro");
  persistAll();
  renderAll();
};
window.cancelPro = () => {
  pro.isPro = false;
  pro.since = null;
  pro.proMembers = [];
  profile.role = "Free Plan";
  log("subscription", "Cancelled Pro");
  persistAll();
  renderAll();
};

/* ===================== EXPORT / RESET ===================== */
function exportJSON() {
  const pack = { profile, pro, theme, locale, currency, state };
  const blob = new Blob([JSON.stringify(pack, null, 2)], {
    type: "application/json"
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "pulsedesk-backup.json";
  a.click();
  URL.revokeObjectURL(url);
}
function resetDemo() {
  state = structuredClone(DEMO);
  persistAll();
  renderAll();
}

/* ===================== THEME / MODULES ===================== */
function initStudio() {
  // minimal studio init if you didn’t paste earlier studio JS
}
function applyTheme() {
  const root = document.documentElement;
  root.dataset.mode = theme.mode;
  root.style.setProperty("--primary", theme.primary);
  root.style.setProperty("--accent", theme.accent);
  root.style.setProperty("--bg-glow", theme.bgGlow);
  root.style.setProperty("--radius", theme.radius + "px");
  root.style.setProperty("--density", theme.density);
  root.style.setProperty("--font-scale", theme.fontScale);
}
function applyModuleVisibility() {
  $$("[data-module]").forEach((el) => {
    const key = el.dataset.module;
    el.style.display = theme.modules[key] ? "" : "none";
  });
}

/* ===================== LOCALE / CURRENCY ===================== */
function initLocaleCurrencySelectors() {
  const localeSelect = $("#localeSelect");
  const currencySelect = $("#currencySelect");

  const locales = [
    "en-US",
    "en-GB",
    "en-JM",
    "es-ES",
    "fr-FR",
    "pt-BR",
    "de-DE",
    "ja-JP",
    "zh-CN"
  ];
  localeSelect.innerHTML = locales
    .map((l) => `<option value="${l}">${l}</option>`)
    .join("");
  localeSelect.value = locale;

  const curr = [
    "USD",
    "EUR",
    "GBP",
    "JMD",
    "CAD",
    "AUD",
    "NGN",
    "GHS",
    "ZAR",
    "KES",
    "JPY",
    "CNY"
  ];
  currencySelect.innerHTML = curr
    .map((c) => `<option value="${c}">${c}</option>`)
    .join("");
  currencySelect.value = currency;

  localeSelect.onchange = (e) => {
    locale = e.target.value;
    localStorage.setItem(LOCALE_KEY, locale);
    renderAll();
  };
  currencySelect.onchange = (e) => {
    currency = e.target.value;
    localStorage.setItem(CURR_KEY, currency);
    renderAll();
  };
}

/* ===================== WELCOME ===================== */
function showWelcome(name) {
  $("#welcomeText").textContent = `Welcome, ${name}! 👋`;
  const w = $("#welcome");
  w.classList.remove("hidden");
  w.classList.add("show");
  setTimeout(() => {
    w.classList.remove("show");
    setTimeout(() => w.classList.add("hidden"), 250);
  }, 900);
}

/* ===================== STORAGE ===================== */
function persistAll() {
  save(DATA_KEY, state);
  save(PROFILE_KEY, profile);
  save(THEME_KEY, theme);
  save(PRO_KEY, pro);
}
function load(key) {
  try {
    return JSON.parse(localStorage.getItem(key));
  } catch {
    return null;
  }
}
function save(key, val) {
  localStorage.setItem(key, JSON.stringify(val));
}

/* ===================== UTILS ===================== */
function log(type, text) {
  state.activity.unshift({ id: id(), type, text, time: Date.now() });
}
function fmt(n) {
  try {
    return new Intl.NumberFormat(locale, {
      style: "currency",
      currency,
      maximumFractionDigits: 2
    }).format(n);
  } catch {
    return `${currency} ${Number(n).toLocaleString()}`;
  }
}
function prettyDate(iso) {
  return new Intl.DateTimeFormat(locale, {
    year: "numeric",
    month: "short",
    day: "numeric"
  }).format(new Date(iso));
}
function initials(name) {
  const parts = name.split(" ").filter(Boolean);
  return (
    parts
      .slice(0, 2)
      .map((p) => p[0])
      .join("")
      .toUpperCase() || "G"
  );
}
function id() {
  return crypto.randomUUID();
}
function sum(a) {
  return a.reduce((x, y) => x + y, 0);
}
function todayISO() {
  return new Date().toISOString().slice(0, 10);
}
function addDaysISO(d) {
  const x = new Date();
  x.setDate(x.getDate() + d);
  return x.toISOString().slice(0, 10);
}
function prioClass(p) {
  return p === "high" ? "red" : p === "med" ? "orange" : "green";
}
function statusClass(s) {
  return s === "completed" ? "green" : s === "in review" ? "blue" : "purple";
}
function empty(msg) {
  return `<div class="item"><div class="left"><div class="title">${msg}</div>
          <div class="sub muted">Use the + buttons to add.</div></div></div>`;
}

/* ===================== GLOBAL CRUD ===================== */
window.delIncome = (idVal) => {
  state.money.incomes = state.money.incomes.filter((x) => x.id !== idVal);
  log("money", "Deleted income");
  persistAll();
  renderAll();
};
window.delBill = (idVal) => {
  state.money.bills = state.money.bills.filter((x) => x.id !== idVal);
  log("money", "Deleted bill");
  persistAll();
  renderAll();
};
window.togglePaid = (idVal) => {
  const b = state.money.bills.find((x) => x.id === idVal);
  if (!b) return;
  b.paid = !b.paid;
  log("money", b.paid ? "Bill paid" : "Bill unpaid");
  persistAll();
  renderAll();
};
window.delTask = (idVal) => {
  state.tasks = state.tasks.filter((x) => x.id !== idVal);
  log("work", "Deleted task");
  persistAll();
  renderAll();
};
window.editTask = (idVal) => openTaskModal(idVal);
window.delMember = (idVal) => {
  state.members = state.members.filter((x) => x.id !== idVal);
  log("team", "Removed member");
  persistAll();
  renderAll();
};
window.delAssign = (idVal) => {
  state.assignments = state.assignments.filter((x) => x.id !== idVal);
  log("team", "Deleted assignment");
  persistAll();
  renderAll();
};
window.delMeet = (idVal) => {
  state.meetings = state.meetings.filter((x) => x.id !== idVal);
  log("meetings", "Deleted meeting");
  persistAll();
  renderAll();
};
